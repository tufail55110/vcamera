package virtual.camera.app.util

import android.content.Context
import virtual.camera.app.bean.AppInfo

object ShortcutUtil {


    /**
     * 创建桌面快捷方式
     * @param userID Int userID
     * @param info AppInfo
     */
    fun createShortcut(context: Context,userID: Int, info: AppInfo) {

    }

    private fun showAllowPermissionDialog(context: Context){


    }
}