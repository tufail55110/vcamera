package virtual.camera.app.settings;

import android.util.Log;

public class LogUtil {
    public static void log(String msg) {
        Log.e("VCamera", msg);
    }
}
