package virtual.camera.app.settings;

public class MethodType {
    public static final int TYPE_DISABLE_CAMERA = 1;
    public static final int TYPE_LOCAL_VIDEO = 2;
    public static final int TYPE_NETWORK_VIDEO = 3;
}
